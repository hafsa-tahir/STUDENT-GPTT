import { DashboardSessionSummary } from "@/components/DashboardSessionSummary";
import { AppLoading, AuthError, StudentAppShell } from "@/components/StudentAppShell";
import { useSupabaseAuth } from "@/contexts/SupabaseAuthContext";
import { trpc } from "@/lib/trpc";
import { Activity, ArrowRight, BookOpen, CalendarDays, CheckCircle2, Clock3, Compass, Flame, Layers3, Plus, Search, Sparkles, Target, TrendingUp } from "lucide-react";
import { useEffect } from "react";
import { useLocation } from "wouter";

function eventLabel(event: string) { return event.replaceAll("_", " ").replace(/^./, letter => letter.toUpperCase()); }
function shortDay(date: Date) { return new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(date); }

export default function Dashboard() {
  const { user, loading, authError } = useSupabaseAuth();
  const [, setLocation] = useLocation();
  const dashboard = trpc.workspace.dashboard.useQuery(undefined, { enabled: Boolean(user), retry: 1, refetchOnWindowFocus: false });
  useEffect(() => { if (!loading && !authError && !user) setLocation("/login"); }, [authError, loading, setLocation, user]);
  if (loading) return <AppLoading />;
  if (authError) return <AuthError message={authError} />;
  if (!user) return <AppLoading />;

  const userDisplayName = (user?.user_metadata?.full_name as string | undefined)?.split(" ")[0]
    || (user?.user_metadata?.name as string | undefined)?.split(" ")[0]
    || user?.email?.split("@")[0]
    || "Student";

  const fallbackProfile = {
    id: 1,
    userId: 1,
    preferredName: userDisplayName,
    studyLevel: "University",
    primaryExamGoal: null,
    timezone: "UTC",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const data = dashboard.data || {
    profile: fallbackProfile,
    subjects: [],
    todayItems: [],
    upcomingPlans: [],
    activity: [],
    recentSessions: [],
    sessionMinutesToday: 0,
  };
  const name = data.profile?.preferredName || (user.user_metadata?.full_name as string | undefined)?.split(" ")[0] || "there";
  const completed = data.todayItems.filter(item => item.completedAt).length;
  const completion = data.todayItems.length ? Math.round((completed / data.todayItems.length) * 100) : 0;
  const trend = Array.from({ length: 5 }, (_, index) => {
    const day = new Date(); day.setHours(0, 0, 0, 0); day.setDate(day.getDate() - (4 - index));
    const next = new Date(day); next.setDate(next.getDate() + 1);
    const minutes = data.recentSessions.filter(session => session.startedAt >= day && session.startedAt < next).reduce((sum, session) => sum + session.minutesStudied, 0);
    return { label: shortDay(day), minutes };
  });
  const maxMinutes = Math.max(...trend.map(point => point.minutes), 15);
  const todayFocus = data.todayItems[0];

  return <StudentAppShell><div className="min-h-screen bg-[#FDF3F3] px-4 py-5 sm:px-7 sm:py-8 lg:px-9"><div className="mx-auto max-w-[1380px]">
    <header className="flex flex-wrap items-center justify-between gap-4 rounded-[24px] border border-[#F8E7E7] bg-[#F8E7E7]/85 px-5 py-3.5 shadow-[0_12px_32px_rgba(114,64,96,.08)] sm:px-6"><div className="flex min-w-[220px] flex-1 items-center gap-3 rounded-xl bg-[#FDF3F3] px-3.5 py-2.5 text-[#A070A1]"><Search className="h-4 w-4" /><span className="text-[12px] font-medium">Search your study space</span></div><div className="flex items-center gap-2"><button onClick={() => setLocation("/research")} className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#A070A1] px-4 text-[12px] font-semibold text-[#FDF3F3] shadow-[0_8px_20px_rgba(114,64,96,.15)] hover:bg-[#724060]"><Compass className="h-4 w-4" /> Research</button><button onClick={() => setLocation("/subjects?create=1")} className="inline-flex h-10 items-center gap-2 rounded-xl border border-[#A070A1] bg-[#FDF3F3] px-3.5 text-[12px] font-semibold text-[#724060] hover:bg-[#F8E7E7]"><Plus className="h-4 w-4" /> Add subject</button></div></header>

    <section className="mt-6 flex flex-wrap items-end justify-between gap-5"><div><p className="text-[11px] font-bold uppercase tracking-[.18em] text-[#A070A1]">StudentGPT overview</p><h1 className="mt-2 text-[34px] font-semibold tracking-[-.06em] text-[#724060] sm:text-[42px]">Good to see you, {name}.</h1><p className="mt-2 max-w-2xl text-[14px] leading-6 text-[#724060]/75">A calmer view of today’s study rhythm, your next task, and the learning spaces you are building.</p></div><div className="inline-flex items-center gap-2 rounded-full bg-[#F8E7E7] px-4 py-2 text-[12px] font-semibold text-[#724060]"><Flame className="h-4 w-4 text-[#A070A1]" /> {data.sessionMinutesToday} focused minutes today</div></section>

    <section className="mt-6 grid gap-5 xl:grid-cols-[minmax(0,1.55fr)_minmax(290px,.75fr)]"><div className="space-y-5"><div className="grid gap-4 md:grid-cols-3"><article className="rounded-[24px] bg-[#724060] p-5 text-[#FDF3F3] shadow-[0_16px_35px_rgba(114,64,96,.2)]"><div className="flex items-start justify-between"><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#A070A1] text-[#FDF3F3]"><Target className="h-4 w-4" /></span><span className="text-[11px] font-semibold text-[#F8E7E7]">TODAY</span></div><p className="mt-7 text-[34px] font-semibold tracking-[-.06em]">{completion}%</p><p className="mt-1 text-[12px] text-[#F8E7E7]">Focus completion</p><div className="mt-4 h-1.5 overflow-hidden rounded-full bg-[#A070A1]"><div className="h-full rounded-full bg-[#FDF3F3]" style={{ width: `${completion}%` }} /></div></article>
          <article className="rounded-[24px] border border-[#F8E7E7] bg-[#F8E7E7] p-5 shadow-[0_12px_28px_rgba(114,64,96,.07)]"><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#FDF3F3] text-[#724060]"><BookOpen className="h-4 w-4" /></span><p className="mt-7 text-[34px] font-semibold tracking-[-.06em] text-[#724060]">{data.subjects.length}</p><p className="mt-1 text-[12px] text-[#724060]/70">Active subjects</p><button onClick={() => setLocation("/subjects")} className="mt-4 inline-flex items-center gap-1 text-[11px] font-semibold text-[#A070A1] hover:text-[#724060]">View subjects <ArrowRight className="h-3.5 w-3.5" /></button></article>
          <article className="rounded-[24px] border border-[#F8E7E7] bg-[#FDF3F3] p-5 shadow-[0_12px_28px_rgba(114,64,96,.07)]"><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#F8E7E7] text-[#724060]"><CalendarDays className="h-4 w-4" /></span><p className="mt-7 text-[34px] font-semibold tracking-[-.06em] text-[#724060]">{data.upcomingPlans.length}</p><p className="mt-1 text-[12px] text-[#724060]/70">Upcoming exam plans</p><button onClick={() => setLocation("/planner")} className="mt-4 inline-flex items-center gap-1 text-[11px] font-semibold text-[#A070A1] hover:text-[#724060]">Open planner <ArrowRight className="h-3.5 w-3.5" /></button></article></div>

        <article className="rounded-[26px] border border-[#F8E7E7] bg-[#FDF3F3] p-5 shadow-[0_12px_28px_rgba(114,64,96,.07)] sm:p-6"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-[11px] font-bold uppercase tracking-[.16em] text-[#A070A1]">Study activity</p><h2 className="mt-2 text-[20px] font-semibold tracking-[-.04em] text-[#724060]">Your focused minutes this week</h2></div><span className="inline-flex items-center gap-1.5 rounded-full bg-[#F8E7E7] px-3 py-1.5 text-[11px] font-semibold text-[#724060]"><TrendingUp className="h-3.5 w-3.5" /> Real session history</span></div><div className="mt-7 flex h-36 items-end justify-between gap-3 border-b border-[#F8E7E7] pb-1">{trend.map(point => <div key={point.label} className="flex h-full flex-1 flex-col items-center justify-end gap-2"><span className="text-[10px] font-semibold text-[#724060]">{point.minutes || "–"}</span><div className="w-full max-w-10 rounded-t-xl bg-[#A070A1] transition-all" style={{ height: `${Math.max(7, Math.round((point.minutes / maxMinutes) * 100))}%` }} /><span className="text-[10px] font-medium text-[#A070A1]">{point.label}</span></div>)}</div></article>

        <div className="grid gap-5 md:grid-cols-[1.2fr_.8fr]"><article className="rounded-[26px] border border-[#F8E7E7] bg-[#FDF3F3] p-5 shadow-[0_12px_28px_rgba(114,64,96,.07)]"><div className="flex items-center justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[.16em] text-[#A070A1]">Today’s focus</p><h2 className="mt-2 text-[19px] font-semibold tracking-[-.04em] text-[#724060]">One useful next step.</h2></div><CheckCircle2 className="h-5 w-5 text-[#A070A1]" /></div>{todayFocus ? <div className="mt-5 rounded-2xl bg-[#F8E7E7] p-4"><p className="text-[14px] font-semibold text-[#724060]">{todayFocus.title}</p><p className="mt-1 text-[12px] text-[#724060]/70">{todayFocus.planTitle} · {todayFocus.estimatedMinutes} minute session</p><button onClick={() => setLocation("/planner")} className="mt-4 text-[12px] font-semibold text-[#724060] hover:underline">Continue in planner</button></div> : <div className="mt-5 rounded-2xl bg-[#F8E7E7] p-4"><p className="text-[14px] font-semibold text-[#724060]">Your day is open.</p><p className="mt-1 text-[12px] leading-5 text-[#724060]/70">Add a plan to turn your next deadline into a focused session.</p><button onClick={() => setLocation("/planner")} className="mt-4 text-[12px] font-semibold text-[#724060] hover:underline">Plan a session</button></div>}</article>
          <article className="rounded-[26px] bg-[#A070A1] p-5 text-[#FDF3F3] shadow-[0_12px_28px_rgba(114,64,96,.16)]"><Sparkles className="h-5 w-5" /><p className="mt-5 text-[11px] font-bold uppercase tracking-[.16em] text-[#F8E7E7]">Research studio</p><h2 className="mt-2 text-[20px] font-semibold leading-tight tracking-[-.04em]">Turn a topic into a study board.</h2><button onClick={() => setLocation("/research")} className="mt-5 inline-flex items-center gap-1 text-[12px] font-semibold text-[#FDF3F3] hover:underline">Open research <ArrowRight className="h-3.5 w-3.5" /></button></article></div>
      </div>

      <aside className="space-y-5"><article className="rounded-[26px] border border-[#F8E7E7] bg-[#FDF3F3] p-5 shadow-[0_12px_28px_rgba(114,64,96,.07)]"><div className="flex items-center justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[.16em] text-[#A070A1]">Study signals</p><h2 className="mt-2 text-[19px] font-semibold tracking-[-.04em] text-[#724060]">Recent activity</h2></div><Activity className="h-5 w-5 text-[#A070A1]" /></div><div className="mt-5 space-y-3">{data.activity.length ? data.activity.slice(0, 5).map(event => <div key={event.id} className="flex gap-3"><span className="mt-1 grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-[#F8E7E7] text-[#724060]"><Activity className="h-3 w-3" /></span><div className="min-w-0"><p className="truncate text-[12px] font-semibold text-[#724060]">{eventLabel(event.eventType)}</p><p className="mt-0.5 text-[10px] text-[#A070A1]">{new Date(event.createdAt).toLocaleDateString()}</p></div></div>) : <p className="rounded-xl bg-[#F8E7E7] p-4 text-[12px] leading-5 text-[#724060]/70">Your genuine study actions will collect here.</p>}</div></article>
        <article className="rounded-[26px] border border-[#F8E7E7] bg-[#F8E7E7] p-5 shadow-[0_12px_28px_rgba(114,64,96,.07)]"><div className="flex items-center justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[.16em] text-[#A070A1]">Academic spaces</p><h2 className="mt-2 text-[19px] font-semibold tracking-[-.04em] text-[#724060]">Your study map</h2></div><Layers3 className="h-5 w-5 text-[#A070A1]" /></div><div className="mt-5 space-y-2">{data.subjects.length ? data.subjects.slice(0, 4).map(subject => <button key={subject.id} onClick={() => setLocation("/subjects")} className="flex w-full items-center gap-3 rounded-xl bg-[#FDF3F3] px-3 py-3 text-left hover:bg-[#FDF3F3]/70"><span className="h-8 w-1.5 rounded-full" style={{ backgroundColor: subject.color || "#A070A1" }} /><span className="min-w-0 flex-1"><span className="block truncate text-[12px] font-semibold text-[#724060]">{subject.name}</span><span className="mt-0.5 block truncate text-[10px] text-[#A070A1]">Open academic space</span></span><ArrowRight className="h-3.5 w-3.5 text-[#A070A1]" /></button>) : <button onClick={() => setLocation("/subjects?create=1")} className="w-full rounded-xl bg-[#FDF3F3] p-4 text-left text-[12px] font-semibold text-[#724060]">Create your first subject</button>}</div></article>
      </aside></section>
  </div><DashboardSessionSummary minutesToday={data.sessionMinutesToday} sessions={data.recentSessions} /></div></StudentAppShell>;
}
