import express from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./_core/oauth";
import { registerStorageProxy } from "./_core/storageProxy";
import { appRouter } from "./routers";
import { createContext, authenticateSupabaseRequest } from "./_core/context";
import { getPrivateDocumentDownload, uploadPrivatePdf } from "./documentService";
import { getResearchExportFile } from "./researchService";
import { streamLLM } from "./_core/llm";

export function createExpressApp() {
  const app = express();
  
  // Normalize Netlify / Vercel serverless function path prefixes
  app.use((req, _res, next) => {
    if (req.url.startsWith("/.netlify/functions/api")) {
      req.url = req.url.replace("/.netlify/functions/api", "/api");
    }
    next();
  });

  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  app.post(["/api/documents/upload", "/documents/upload"], express.raw({ type: "*/*", limit: "12mb" }), async (req, res) => {
    try {
      const user = await authenticateSupabaseRequest(req);
      if (!user) return res.status(401).json({ error: "Authentication is required." });
      
      let pdfBuffer: Buffer | null = null;
      if (Buffer.isBuffer(req.body) && req.body.length > 0) {
        pdfBuffer = req.body;
      } else if (typeof req.body === "string" && req.body.length > 0) {
        const isBase64 = (req as any).isBase64Encoded || /^[A-Za-z0-9+/=]+\s*$/.test(req.body.slice(0, 100));
        pdfBuffer = Buffer.from(req.body, isBase64 ? "base64" : "binary");
      }
      
      if (!pdfBuffer || !pdfBuffer.length) return res.status(400).json({ error: "PDF content is required." });
      const originalName = typeof req.headers["x-file-name"] === "string" ? decodeURIComponent(req.headers["x-file-name"]) : "study-document.pdf";
      const subjectId = typeof req.headers["x-subject-id"] === "string" && req.headers["x-subject-id"] ? Number(req.headers["x-subject-id"]) : null;
      const document = await uploadPrivatePdf(user.id, { buffer: pdfBuffer, name: originalName, mimeType: "application/pdf", subjectId: Number.isInteger(subjectId) && subjectId! > 0 ? subjectId : null });
      return res.status(201).json({ document });
    } catch (error) { return res.status(400).json({ error: error instanceof Error ? error.message : "Upload failed." }); }
  });

  app.get(["/api/documents/:documentId/download", "/documents/:documentId/download"], async (req, res) => {
    try {
      const user = await authenticateSupabaseRequest(req);
      if (!user) return res.status(401).json({ error: "Authentication is required." });
      const id = Number(req.params.documentId);
      if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ error: "Invalid document." });
      const signedUrl = await getPrivateDocumentDownload(user.id, id);
      return res.redirect(302, signedUrl);
    } catch { return res.status(404).json({ error: "Document not found." }); }
  });

  app.get(["/api/research-exports/:exportId/download", "/research-exports/:exportId/download"], async (req, res) => {
    try {
      const user = await authenticateSupabaseRequest(req);
      if (!user) return res.status(401).json({ error: "Authentication is required." });
      const id = Number(req.params.exportId);
      if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ error: "Invalid research export." });
      const file = await getResearchExportFile(user.id, id);
      const safeFileName = file.fileName.replace(/[\r\n"]/g, "_");
      res.status(200).set({ "Content-Type": file.mimeType, "Content-Length": String(file.bytes.byteLength), "Content-Disposition": `attachment; filename="${safeFileName}"; filename*=UTF-8''${encodeURIComponent(safeFileName)}`, "Cache-Control": "private, no-store" });
      return res.send(file.bytes);
    } catch { return res.status(404).json({ error: "Research export not found." }); }
  });

  app.post(["/api/chat/stream", "/chat/stream"], async (req, res) => {
    try {
      const user = await authenticateSupabaseRequest(req);
      if (!user) return res.status(401).json({ error: "Authentication is required." });
      const content = typeof req.body?.content === "string" ? req.body.content.trim() : "";
      if (!content || content.length > 12000) return res.status(400).json({ error: "A valid study question is required." });
      const upstream = await streamLLM({ messages: [{ role: "system", content: "You are StudentGPT, a careful academic assistant. Use concise Markdown and acknowledge uncertainty rather than inventing claims." }, { role: "user", content }] });
      if (!upstream.body) throw new Error("The AI provider did not return a response stream.");
      res.status(200).set({ "Content-Type": "text/event-stream", "Cache-Control": "no-cache, no-transform", Connection: "keep-alive" });
      const reader = upstream.body.getReader(); const decoder = new TextDecoder(); let cancelled = false;
      res.on("close", () => { cancelled = true; reader.cancel().catch(() => undefined); });
      while (!cancelled) { const { done, value } = await reader.read(); if (done) break; res.write(decoder.decode(value, { stream: true })); }
      res.end();
    } catch (error) { if (!res.headersSent) res.status(500).json({ error: error instanceof Error ? error.message : "Stream unavailable." }); else res.end(); }
  });

  app.get(["/api/auth/supabase-config", "/auth/supabase-config"], (_req, res) => {
    const url = process.env.SUPABASE_URL;
    const anonKey = process.env.SUPABASE_ANON_KEY;
    if (!url || !anonKey) {
      return res.status(503).json({ error: "Authentication is not configured." });
    }
    return res.json({ url, anonKey });
  });

  registerStorageProxy(app);
  registerOAuthRoutes(app);

  // tRPC API middleware mounted on all route variations
  const trpcHandler = createExpressMiddleware({
    router: appRouter,
    createContext,
  });

  app.use("/.netlify/functions/api/trpc", trpcHandler);
  app.use("/.netlify/functions/api/api/trpc", trpcHandler);
  app.use("/api/trpc", trpcHandler);
  app.use("/trpc", trpcHandler);

  // Catch-all JSON fallback for any unhandled requests to prevent HTML responses
  app.use("*", (_req, res) => {
    res.status(404).json({ error: { message: "API endpoint not found." } });
  });

  // Global Express error handler returning JSON instead of HTML
  app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error("[Express Error]", err);
    res.status(err?.status || 500).json({ error: { message: err?.message || "Internal server error." } });
  });

  return app;
}
